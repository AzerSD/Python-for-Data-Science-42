# ft_package

A sample Python package that provides a function to count occurrences of an item in a list.

## Installation

```bash
pip install ./dist/ft_package-0.0.1.tar.gz