def count_in_list(lst, item):
    """Counts the occurrences of an item in a list."""
    return lst.count(item)
